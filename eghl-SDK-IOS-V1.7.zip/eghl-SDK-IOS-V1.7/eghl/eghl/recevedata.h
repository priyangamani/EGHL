//
//  recevedata.h
//  eghl
//
//  Created by xiami on 15/1/24.
//  Copyright (c) 2015年 eghl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface recevedata : NSObject

@property (strong, nonatomic) NSString *recedata1;
@property (strong, nonatomic) NSString *recedata2;

@end
