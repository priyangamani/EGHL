//
//  ViewController.h
//  eghl
//
//  Created by mac on 15/1/21.
//  Copyright (c) 2015年 eghl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGHLPayment.h"
#import "ShowViewController.h"

@interface ViewController : UIViewController<UITextFieldDelegate>
{
    EGHLPayment *eghlpay;
    PaymentRequestPARAM *paypram;
    UILabel *ShowMsg;
}

@property (strong, nonatomic) IBOutlet UITextField *Amount;
@property (strong, nonatomic) IBOutlet UITextField *Merchant;
@property (strong, nonatomic) IBOutlet UITextField *Email;
@property (strong, nonatomic) IBOutlet UITextField *Customer;
@property (strong, nonatomic) IBOutlet UITextField *ServiceID;
@property (strong, nonatomic) IBOutlet UITextField *Password;
@property (strong, nonatomic) IBOutlet UITextField *Currency;

@property (strong, nonatomic) IBOutlet UISegmentedControl *TokenSegCon;
@property (strong, nonatomic) IBOutlet UISegmentedControl *PayMethod;
@property (strong, nonatomic) IBOutlet UISegmentedControl *Bank;
@property (strong, nonatomic) IBOutlet UISwitch *HostSwitch;


@property (weak, nonatomic) IBOutlet UIButton *SaleReq;
@property (weak, nonatomic) IBOutlet UIButton *QueryReq;
@property (weak, nonatomic) IBOutlet UIButton *Reversal;

@end





