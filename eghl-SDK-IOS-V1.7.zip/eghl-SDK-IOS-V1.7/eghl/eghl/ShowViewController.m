//
//  ShowViewController.m
//  eghl
//
//  Created by mac on 15/1/27.
//  Copyright (c) 2015年 eghl. All rights reserved.
//

#import "ShowViewController.h"

@interface ShowViewController ()

@end

@implementation ShowViewController
@synthesize paypram;

-(id)initWithValue:(PaymentRequestPARAM *)payment
{
    self = [super init];
    
    if (self) {
        paypram = payment;
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIButton * button = [[UIButton alloc] initWithFrame:CGRectZero];
    [button setClipsToBounds:YES];
    [button.titleLabel setFont:[UIFont boldSystemFontOfSize:17]];

    [button setTitle:@"Back" forState:UIControlStateNormal];
    [button sizeToFit];
    
    [button addTarget:self
               action:@selector(backButtonPressed:)
     forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.navigationController.interactivePopGestureRecognizer.delegate = (id<UIGestureRecognizerDelegate>)self;
    
    eghlpay = [[EGHLPayment alloc]initWithFrame:CGRectMake(0, 30, 320, 538)];
    eghlpay.delegate = self;
    [self.view addSubview:eghlpay];
    
    [eghlpay EGHLRequestSale:paypram successBlock:^(NSString* SuccessData) {
        NSLog(@"SuccessData:%@",SuccessData);
    } failedBlock:^(NSString*errorCode,NSString *errorData) {
        NSLog(@"errorcode:%@ errordata:%@",errorCode,errorData);
    }];
}

- (void)backButtonPressed:(id)sender{
    UIAlertView * alertExit = [[UIAlertView alloc] initWithTitle:@"Are you sure you want to quit" message:@"Pressing BACK button will close and abandon the payment session." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Exit", nil];
    
    [alertExit setTag:100];
    [alertExit show];
}

- (void)QueryResult:(PaymentRespPARAM *)result
{
    /*************************************
     Query current transaction status.
     TxnStatus:
     0 = transaction success
     1 = transaction failed
     2 = sale pending, retry query
     TxnExists:
     0 – Transaction being queried exists in Payment Gateway.
     1 – Transaction being queried does not exist in Payment Gateway.
     TxnStatus will be -1
     2 – There was some kind of internal error occurred during query processing. Merchant System can retry sending query request
     TxnStatus will be -2
     **************************************/
    NSLog(@"TxnExists:%@,QueryDesc:%@,TransactionType:%@,PymtMethod:%@,ServiceID:%@,PaymentID:%@,OrderNumber:%@,Amount:%@ \
          CurrencyCode:%@,TxnID:%@,IssuingBank:%@,AuthCode:%@,TxnStatus:%@,BankRefNo:%@,TxnMessage:%@,HashValue:%@,SessionID:%@",\
          result.TxnExists,result.QueryDesc,result.TransactionType,result.PymtMethod,result.ServiceID,result.PaymentID,result.OrderNumber,result.Amount,result.CurrencyCode,result.TxnID,result.IssuingBank,result.AuthCode,\
          result.TxnStatus,result.BankRefNo,result.TxnMessage,result.HashValue,result.SessionID);
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)QueryResult:(NSString *)statusCode   Status:(NSString *)statusData
{
    //if get the MerchantReturnURL or Merchant cancel payment page link will called.
    
    if ([statusCode isEqualToString:@"0"] || [statusData isEqualToString:@"PAYMENT FINISHED"]) {
        PaymentRequestPARAM *payparam   = [[PaymentRequestPARAM alloc]init];
        payparam.Amount                 = paypram.Amount;
        payparam.Password               = paypram.Password;
        payparam.ServiceID              = paypram.ServiceID;
        payparam.PaymentID              = paypram.PaymentID;
        payparam.PymtMethod             = paypram.PymtMethod;
        payparam.CurrencyCode           = paypram.CurrencyCode;
        
        [eghlpay EGHLRequestQuery:payparam successBlock:^(PaymentRespPARAM* ParamData) {
            NSLog(@"TxnStatus:%@,TxnMessage:%@,TxnExists:%@,QueryDesc:%@,TransactionType:%@,PymtMethod:%@,ServiceID:%@,PaymentID:%@,OrderNumber:%@,Amount:%@ \
                  CurrencyCode:%@,TxnID:%@,IssuingBank:%@,AuthCode:%@,BankRefNo:%@,HashValue:%@,SessionID:%@,HashValue2:%@",
                  ParamData.TxnStatus,ParamData.TxnMessage,ParamData.TxnExists,ParamData.QueryDesc,ParamData.TransactionType,ParamData.PymtMethod,ParamData.ServiceID,ParamData.PaymentID,ParamData.OrderNumber,ParamData.Amount,ParamData.CurrencyCode,ParamData.TxnID,ParamData.IssuingBank,ParamData.AuthCode,
                  ParamData.BankRefNo,ParamData.HashValue,ParamData.SessionID,ParamData.HashValue2);
        } failedBlock:^(NSString *errorCode,NSString *errorData) {}];
    }else{
        NSLog(@"statusCode:%@,statusData:%@",statusCode,statusData);
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    /*************************************
        Query current transaction status.
        TxnStatus:
            0 = transaction success
            1 = transaction failed
            2 = sale pending, retry query
        TxnExists:
            0 – Transaction being queried exists in Payment Gateway.
            1 – Transaction being queried does not exist in Payment Gateway.
                TxnStatus will be -1
            2 – There was some kind of internal error occurred during query processing. Merchant System can retry sending query request
                TxnStatus will be -2
    **************************************/
    PaymentRequestPARAM *payparam   = [[PaymentRequestPARAM alloc]init];
    payparam.Amount                 = paypram.Amount;
    payparam.Password               = paypram.Password;
    payparam.ServiceID              = paypram.ServiceID;
    payparam.PaymentID              = paypram.PaymentID;
    payparam.PymtMethod             = paypram.PymtMethod;
    payparam.CurrencyCode           = paypram.CurrencyCode;
    
    [eghlpay EGHLRequestQuery:payparam successBlock:^(PaymentRespPARAM* ParamData) {
            NSLog(@"2TxnStatus:%@,TxnMessage:%@,TxnExists:%@,QueryDesc:%@,TransactionType:%@,PymtMethod:%@,ServiceID:%@,PaymentID:%@,OrderNumber:%@,Amount:%@ \
                  CurrencyCode:%@,TxnID:%@,IssuingBank:%@,AuthCode:%@,BankRefNo:%@,HashValue:%@,SessionID:%@,HashValue2:%@",\
                  ParamData.TxnStatus,ParamData.TxnMessage,ParamData.TxnExists,ParamData.QueryDesc,ParamData.TransactionType,ParamData.PymtMethod,ParamData.ServiceID,ParamData.PaymentID,ParamData.OrderNumber,ParamData.Amount,ParamData.CurrencyCode,ParamData.TxnID,ParamData.IssuingBank,ParamData.AuthCode,\
                  ParamData.BankRefNo,ParamData.HashValue,ParamData.SessionID,ParamData.HashValue2);
    } failedBlock:^(NSString *errorCode,NSString *errorData) {}];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
