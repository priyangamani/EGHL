//
//  ViewController.m
//  eghl
//
//  Created by mac on 15/1/21.
//  Copyright (c) 2015年 eghl. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController
@synthesize SaleReq;
@synthesize QueryReq;
@synthesize Reversal;
@synthesize Amount;
@synthesize Merchant;
@synthesize Email;
@synthesize Customer;
@synthesize ServiceID;
@synthesize Password;
@synthesize Currency;
@synthesize TokenSegCon;
@synthesize HostSwitch;
@synthesize PayMethod;
@synthesize Bank;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
    
    paypram = [[PaymentRequestPARAM alloc]init];
    eghlpay = [[EGHLPayment alloc]init];
    
    self.Amount.text = @"10.00";
    self.Merchant.text = @"eGHL Payment Testing";
    self.Email.text = @"jeff.phang@ghl.com";
    self.Customer.text = @"Jeff";
    self.ServiceID.text = @"GHL";
    self.Password.text = @"ghl12345";
    self.Currency.text = @"MYR";
    
    paypram.Amount =  self.Amount.text;
    paypram.MerchantName = self.Merchant.text;
    paypram.CustEmail = self.Email.text;
    paypram.CustName = self.Customer.text;
    paypram.ServiceID = self.ServiceID.text;
    paypram.Password = self.Password.text;
    paypram.CurrencyCode = self.Currency.text;
    
    Amount.delegate = self;
    Merchant.delegate = self;
    Email.delegate = self;
    Customer.delegate = self;
    ServiceID.delegate = self;
    Password.delegate = self;
    Currency.delegate = self;
    
    int value =arc4random_uniform(9999999 + 1);
    paypram.PaymentID = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    paypram.OrderNumber = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    
    TokenSegCon.selectedSegmentIndex = 0;
    TokenSegCon.tag = 0;
    PayMethod.selectedSegmentIndex = 0;
    PayMethod.tag = 2;
    Bank.selectedSegmentIndex = 0;
    Bank.tag = 3;
    
    [TokenSegCon addTarget:self action:@selector(didClicksegmentedControlAction:) forControlEvents:UIControlEventValueChanged];
    [PayMethod addTarget:self action:@selector(didClicksegmentedControlAction:) forControlEvents:UIControlEventValueChanged];
    [Bank addTarget:self action:@selector(didClicksegmentedControlAction:) forControlEvents:UIControlEventValueChanged];
    
    [HostSwitch setOn:NO];
    [HostSwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    
    paypram.CardExp = @"1020";
    paypram.CardHolder = @"YAM TEE YEN";
    paypram.CardNo = @"5401190420329107";
//    paypram.MerchantReturnURL = @"http://210.19.206.147:8084/ctos_tenancy/payment/confirm.action";
    paypram.MerchantReturnURL = @"https://test2pay.ghl.com/IPGSimulatorJeff/RespFrmGW.aspx";
//    paypram.MerchantCallBackURL = @"";
//    paypram.B4TaxAmt = @"74.99";
//    paypram.TaxAmt = @"11.22";
//    paypram.Param6 = @"";
//    paypram.Param7 = @"";
    paypram.CustPhone = @"0123456789";
    paypram.LanguageCode = @"EN";
    paypram.PaymentDesc = @"just buy something";
    paypram.PageTimeout = @"500";
    paypram.IssuingBank = @"CIMB";
    paypram.PymtMethod = @"ANY";
    paypram.TokenType = @"OCP";
    paypram.Token = @"duo9LGT7JC8b+uGkGhvdHg==";
    
    [SaleReq addTarget:self action:@selector(SaleReqBtn:) forControlEvents:UIControlEventTouchUpInside];
    [QueryReq addTarget:self action:@selector(QueryReqBtn:) forControlEvents:UIControlEventTouchUpInside];
    [Reversal addTarget:self action:@selector(ReversalReqBtn:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)switchAction:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn) {
         self.Merchant.text = @"eGHL Payment";
         paypram.MerchantName = self.Merchant.text;
         self.Password.text = @"Gh1eG3H1";
         paypram.Password = self.Password.text;
         self.ServiceID.text = @"ghl";
         paypram.ServiceID = self.ServiceID.text;
         paypram.RealHost = YES;
    }else {
         self.Merchant.text = @"eGHL Payment Testing";
         paypram.MerchantName = self.Merchant.text;
         self.Password.text = @"ghl12345";
         paypram.Password = self.Password.text;
         self.ServiceID.text = @"GHL";
         paypram.ServiceID = self.ServiceID.text;
         paypram.RealHost = NO;
    }
}

-(void)didClicksegmentedControlAction:(UISegmentedControl *)Seg{
    NSInteger Index = Seg.selectedSegmentIndex;
    switch (Index) {
        case 0:
            if (Seg.tag == 0) {
                paypram.TokenType = @"OCP";
                paypram.Token = @"duo9LGT7JC8b+uGkGhvdHg==";
            }else if(Seg.tag == 1){
            }else if(Seg.tag == 2){
                paypram.PymtMethod = @"ANY";
            }else if(Seg.tag == 3){
                paypram.IssuingBank = @"CIMB";
            }
            break;
        case 1:
            if (Seg.tag == 0) {
                paypram.TokenType = @"";
                paypram.Token = @"";
            }else if(Seg.tag == 1){
            }else if(Seg.tag == 2){
                paypram.PymtMethod = @"CC";
            }else if (Seg.tag == 3){
                paypram.IssuingBank = @"RHB";
            }
            break;
        case 2:
            if (Seg.tag == 2) {
                paypram.PymtMethod = @"DD";
            }else if (Seg.tag == 3){
                paypram.IssuingBank = @"FPX";
            }
            break;
        case 3:
            if (Seg.tag == 2) {
                paypram.PymtMethod = @"OTC";
            }else if (Seg.tag == 3){
                paypram.IssuingBank = @"FPXD";
            }
            break;
        default:
            break;
    }
}


-(void)SaleReqBtn:(UIButton *)btnSale
{
    int value =arc4random_uniform(9999999 + 1);
    paypram.PaymentID = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    paypram.OrderNumber = [NSString stringWithFormat:@" %d",value];
    paypram.Amount =  self.Amount.text;
    paypram.MerchantName = self.Merchant.text;
    paypram.CustEmail = self.Email.text;
    paypram.CustName = self.Customer.text;
    paypram.ServiceID = self.ServiceID.text;
    paypram.Password = self.Password.text;
    paypram.CurrencyCode = self.Currency.text;
    
    NSLog(@"Amount:%@ Merchant:%@ Email:%@ Customer:%@ ServiceID:%@ Password:%@ Currency:%@ TokenType:%@ Token:%@ PayMethod:%@ Bank:%@ PaymentID:%@ OrderNumber:%@",\
          paypram.Amount,paypram.MerchantName,paypram.CustEmail,paypram.CustName,paypram.ServiceID,paypram.Password,paypram.CurrencyCode,paypram.TokenType,paypram.Token,paypram.PymtMethod,paypram.IssuingBank,paypram.PaymentID,paypram.OrderNumber);
    ShowViewController *Payviewcontroller = [[ShowViewController alloc] initWithValue:paypram];
    [self.navigationController pushViewController:Payviewcontroller animated:YES];
}


-(void)QueryReqBtn:(UIButton *)btnSale
{
    /*************************************
     Query current transaction status.
     TxnStatus:
     0 = transaction success
     1 = transaction failed
     2 = sale pending, retry query
     TxnExists:
     0 – Transaction being queried exists in Payment Gateway.
     1 – Transaction being queried does not exist in Payment Gateway.
     TxnStatus will be -1
     2 – There was some kind of internal error occurred during query processing. Merchant System can retry sending query request
     TxnStatus will be -2
     **************************************/
    int value =arc4random_uniform(9999999 + 1);
    paypram.PaymentID = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    paypram.OrderNumber = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    
    [eghlpay EGHLRequestQuery:paypram successBlock:^(PaymentRespPARAM* ParamData) {
        NSLog(@"TxnExists:%@,QueryDesc:%@,TransactionType:%@,PymtMethod:%@,ServiceID:%@,PaymentID:%@,OrderNumber:%@,Amount:%@ \
              CurrencyCode:%@,TxnID:%@,IssuingBank:%@,AuthCode:%@,TxnStatus:%@,BankRefNo:%@,TxnMessage:%@,HashValue:%@,SessionID:%@",\
              ParamData.TxnExists,ParamData.QueryDesc,ParamData.TransactionType,ParamData.PymtMethod,ParamData.ServiceID,ParamData.PaymentID,ParamData.OrderNumber,ParamData.Amount,ParamData.CurrencyCode,ParamData.TxnID,ParamData.IssuingBank,ParamData.AuthCode,\
              ParamData.TxnStatus,ParamData.BankRefNo,ParamData.TxnMessage,ParamData.HashValue,ParamData.SessionID);
    } failedBlock:^(NSString *errorCode, NSString *errorData) {
        NSLog(@"respdata:%@",errorData);
    }];
}


-(void)ReversalReqBtn:(UIButton *)btnSale
{
    //int value =arc4random_uniform(9999999 + 1);
    //paypram.PaymentID = [NSString stringWithFormat:@"CNASIT7791896%d",value];
    //paypram.OrderNumber = [NSString stringWithFormat:@"CNASIT7791896%d",value];

    [eghlpay EGHLRequestReversal:paypram successBlock:^(PaymentRespPARAM* ParamData) {
        NSLog(@"TxnExists:%@,QueryDesc:%@,TransactionType:%@,PymtMethod:%@,ServiceID:%@,PaymentID:%@,OrderNumber:%@,Amount:%@ \
                            CurrencyCode:%@,TxnID:%@,IssuingBank:%@,AuthCode:%@,TxnStatus:%@,BankRefNo:%@,TxnMessage:%@,HashValue:%@,SessionID:%@",\
                            ParamData.TxnExists,ParamData.QueryDesc,ParamData.TransactionType,ParamData.PymtMethod,ParamData.ServiceID,ParamData.PaymentID,ParamData.OrderNumber,ParamData.Amount,ParamData.CurrencyCode,ParamData.TxnID,ParamData.IssuingBank,ParamData.AuthCode,\
                            ParamData.TxnStatus,ParamData.BankRefNo,ParamData.TxnMessage,ParamData.HashValue,ParamData.SessionID);
    } failedBlock:^(NSString *errorCode,NSString *errorData) {
        NSLog(@"errorcode:%@ errordata:%@",errorCode,errorData);
    }];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void)viewTapped:(UITapGestureRecognizer*)tapGr{
    [Amount resignFirstResponder];
    [Merchant resignFirstResponder];
    [Email resignFirstResponder];
    [Customer resignFirstResponder];
    [ServiceID resignFirstResponder];
    [Password resignFirstResponder];
    [Currency resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
